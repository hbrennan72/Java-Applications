
/***********************
 * Hugh Brennan
 * CITP 190
 * March 23, 2012
 * Project 8
 * *********************
*/

public interface Depositable 

{
	public void deposit(double amount);
}
