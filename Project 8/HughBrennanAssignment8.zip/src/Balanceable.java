/***********************
 * Hugh Brennan
 * CITP 190
 * March 23, 2012
 * Project 8
 * ********************/

public interface Balanceable 

{
	public double getBalance();
	public void setBalance(double amount);
		
}